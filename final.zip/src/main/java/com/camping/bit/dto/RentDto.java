package com.camping.bit.dto;

public class RentDto {

}
