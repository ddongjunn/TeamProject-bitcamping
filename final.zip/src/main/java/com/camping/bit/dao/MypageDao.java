package com.camping.bit.dao;

public interface MypageDao {
}
